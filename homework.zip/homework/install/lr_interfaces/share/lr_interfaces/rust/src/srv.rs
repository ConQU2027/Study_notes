#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};




// Corresponds to lr_interfaces__srv__CarHeight_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CarHeight_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub target_height: i32,

}



impl Default for CarHeight_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CarHeight_Request::default())
  }
}

impl rosidl_runtime_rs::Message for CarHeight_Request {
  type RmwMsg = super::srv::rmw::CarHeight_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        target_height: msg.target_height,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      target_height: msg.target_height,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      target_height: msg.target_height,
    }
  }
}


// Corresponds to lr_interfaces__srv__CarHeight_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CarHeight_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub current_height: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub days: i32,

}



impl Default for CarHeight_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CarHeight_Response::default())
  }
}

impl rosidl_runtime_rs::Message for CarHeight_Response {
  type RmwMsg = super::srv::rmw::CarHeight_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        current_height: msg.current_height,
        days: msg.days,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      current_height: msg.current_height,
      days: msg.days,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      current_height: msg.current_height,
      days: msg.days,
    }
  }
}






#[link(name = "lr_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__lr_interfaces__srv__CarHeight() -> *const std::ffi::c_void;
}

// Corresponds to lr_interfaces__srv__CarHeight
#[allow(missing_docs, non_camel_case_types)]
pub struct CarHeight;

impl rosidl_runtime_rs::Service for CarHeight {
    type Request = CarHeight_Request;
    type Response = CarHeight_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__lr_interfaces__srv__CarHeight() }
    }
}


