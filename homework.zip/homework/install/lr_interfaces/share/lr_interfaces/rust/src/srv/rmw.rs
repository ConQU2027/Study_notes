#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



#[link(name = "lr_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__lr_interfaces__srv__CarHeight_Request() -> *const std::ffi::c_void;
}

#[link(name = "lr_interfaces__rosidl_generator_c")]
extern "C" {
    fn lr_interfaces__srv__CarHeight_Request__init(msg: *mut CarHeight_Request) -> bool;
    fn lr_interfaces__srv__CarHeight_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CarHeight_Request>, size: usize) -> bool;
    fn lr_interfaces__srv__CarHeight_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CarHeight_Request>);
    fn lr_interfaces__srv__CarHeight_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CarHeight_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<CarHeight_Request>) -> bool;
}

// Corresponds to lr_interfaces__srv__CarHeight_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CarHeight_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub target_height: i32,

}



impl Default for CarHeight_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !lr_interfaces__srv__CarHeight_Request__init(&mut msg as *mut _) {
        panic!("Call to lr_interfaces__srv__CarHeight_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CarHeight_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { lr_interfaces__srv__CarHeight_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { lr_interfaces__srv__CarHeight_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { lr_interfaces__srv__CarHeight_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CarHeight_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CarHeight_Request where Self: Sized {
  const TYPE_NAME: &'static str = "lr_interfaces/srv/CarHeight_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__lr_interfaces__srv__CarHeight_Request() }
  }
}


#[link(name = "lr_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__lr_interfaces__srv__CarHeight_Response() -> *const std::ffi::c_void;
}

#[link(name = "lr_interfaces__rosidl_generator_c")]
extern "C" {
    fn lr_interfaces__srv__CarHeight_Response__init(msg: *mut CarHeight_Response) -> bool;
    fn lr_interfaces__srv__CarHeight_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CarHeight_Response>, size: usize) -> bool;
    fn lr_interfaces__srv__CarHeight_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CarHeight_Response>);
    fn lr_interfaces__srv__CarHeight_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CarHeight_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<CarHeight_Response>) -> bool;
}

// Corresponds to lr_interfaces__srv__CarHeight_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CarHeight_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub current_height: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub days: i32,

}



impl Default for CarHeight_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !lr_interfaces__srv__CarHeight_Response__init(&mut msg as *mut _) {
        panic!("Call to lr_interfaces__srv__CarHeight_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CarHeight_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { lr_interfaces__srv__CarHeight_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { lr_interfaces__srv__CarHeight_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { lr_interfaces__srv__CarHeight_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CarHeight_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CarHeight_Response where Self: Sized {
  const TYPE_NAME: &'static str = "lr_interfaces/srv/CarHeight_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__lr_interfaces__srv__CarHeight_Response() }
  }
}






#[link(name = "lr_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__lr_interfaces__srv__CarHeight() -> *const std::ffi::c_void;
}

// Corresponds to lr_interfaces__srv__CarHeight
#[allow(missing_docs, non_camel_case_types)]
pub struct CarHeight;

impl rosidl_runtime_rs::Service for CarHeight {
    type Request = CarHeight_Request;
    type Response = CarHeight_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__lr_interfaces__srv__CarHeight() }
    }
}


